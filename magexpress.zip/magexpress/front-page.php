<?php get_header(); ?>
<section id="mainContent">
    <div class="content_top">
        <div class="row">
            <!-- banner Post Slider -->
            <?php get_template_part('template-parts/banner_slider'); ?>
            <!-- banner right News -->
            <?php get_template_part('template-parts/banner_right'); ?>
        </div>
    </div>
    <div class="content_middle">
        <div class="col-lg-3 col-md-3 col-sm-3">
            <!-- 3 column Left News eg: Bollywood -->
            <?php get_template_part('template-parts/three_colum_left'); ?>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6">
            <!-- Middle Slider News-->
            <?php get_template_part('template-parts/three_column_slider'); ?>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3">
            <!-- Category Right News eg: Hollywood -->
            <?php get_template_part('template-parts/three_column_right'); ?>
        </div>
    </div>
    <div class="content_bottom">
        <div class="col-lg-8 col-md-8">
            <div class="content_bottom_left">
               <!-- category bottom first  -->
               <?php get_template_part('template-parts/double_column_first'); ?>
                <div class="games_fashion_area">
                <!-- Games  Category Second-->
                <div class="games_category">
                <?php get_template_part('template-parts/single_column_first'); ?>
                </div>
                <!-- Fashion Category Third-->
                <div class="fashion_category">
                <?php get_template_part('template-parts/single_column_second'); ?>
                </div>
                </div>
                <div class="technology_catrarea">
                    <!-- category bottom four  -->
               <?php get_template_part('template-parts/double_column_second'); ?>
                </div>
            </div>
        </div>
        <?php get_sidebar(); ?>
    </div>
</section>
</div>
<?php get_footer(); ?>