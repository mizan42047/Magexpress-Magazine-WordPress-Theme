<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mag_Express
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<!-- <div id="preloader">
  <div id="status">&nbsp;</div>
</div> -->
<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
<div class="container">
  <header id="header">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="header_top">
          <div class="header_top_left">
            <?php 
            
            wp_nav_menu([
              'menu' => 'topbar-menu',
              'menu_class' => 'top_nav',
              'container' => ' ',
              'theme_location'=> 'topbar-menu'
            ])
            
            ?>
          </div>
          <div class="header_top_right">
          <?php get_search_form(); ?>
          </div>
        </div>
        <div class="header_bottom">
          <?php if(!has_custom_logo()): ?>
          <div class="header_bottom_left"><a class="logo" href="<?php echo esc_url(site_url()); ?>"><strong><?php bloginfo('name'); ?></strong> <span><?php bloginfo('description'); ?></span></a></div>
          <?php else: ?>
            <?php the_custom_logo(); ?>
          <?php endif; ?>
          <?php if(get_theme_mod('header_banner_img')): ?>

          <div class="header_bottom_right"><a href="<?php echo esc_url(get_theme_mod('header_banner_img_link',true)); ?>"><img src="<?php echo esc_url((get_theme_mod('header_banner_img'))); ?>" alt="<?php esc_attr(bloginfo('name')); ?>"></a></div>

          <?php endif; ?>
        </div>
      </div>
    </div>
  </header>
  <div id="navarea">
    <nav class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
         <div id="navbar" class="navbar-collapse collapse">

          <?php 
          $primary_nav = wp_nav_menu([
            'menu' => 'main-menu',
            'menu_class' => 'nav navbar-nav custom_nav',
            'container' => ' ',
            'echo'      => false,
          ]);

          $primary_nav = str_replace('menu-item-has-children','menu-item-has-children dropdown',$primary_nav);
          $primary_nav = str_replace('sub-menu','sub-menu dropdown-menu', $primary_nav);

          echo $primary_nav;

          ?>
        </div>
      </div>
    </nav>
  </div>
