<?php
define('SINGLECOLUMNSECTIONFIRST','magexpress_single_column_first_section_id');

/**
 * Theme first single column area post control Section.
 */
Kirki::add_section( SINGLECOLUMNSECTIONFIRST, array(
    'title'          => esc_html__( 'Single Column First', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your single column area post', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * single Column first Title 
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'single_column_first_title',
	'label'    => esc_html__( 'Single Column First Title', 'magexpress' ),
	'section'  => SINGLECOLUMNSECTIONFIRST,
	'default'  => esc_html__( 'Category Name', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'single_column_first_title' => [
			'selector'        => '.single_column_first_title',
			'render_callback' => function() {
				return get_theme_mod('single_column_first_title',true);
			},
		],
	],
] );

/**
 * single Column first category selection
*/

Kirki::add_field( CONFIGID, array(
	'type'     => 'select',
	'settings' => 'single_column_first_category_selection',
	'label'    => esc_html__( 'Select a category for single column', 'magexpress' ),
	'section'  => SINGLECOLUMNSECTIONFIRST,
	'default'  => '1',
	'priority' => 10,
	'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'category') ))
 );

  /**
 * single Colum first Category Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'single_column_first_posts_order',
	'label'       => esc_html__( 'Single Column First Posts Order', 'magexpress' ),
	'section'     => SINGLECOLUMNSECTIONFIRST,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );