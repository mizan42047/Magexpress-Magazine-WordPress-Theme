<?php
define('SINGLECOLUMNSECTIONSECOND','magexpress_single_column_second_section_id');

/**
 * Theme second single column area post control Section.
 */
Kirki::add_section( SINGLECOLUMNSECTIONSECOND, array(
    'title'          => esc_html__( 'Single Column Second', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your single column area post', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * single Column second Title 
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'single_column_second_title',
	'label'    => esc_html__( 'Single Column Second Title', 'magexpress' ),
	'section'  => SINGLECOLUMNSECTIONSECOND,
	'default'  => esc_html__( 'Category Name', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'single_column_second_title' => [
			'selector'        => '.single_column_second_title',
			'render_callback' => function() {
				return get_theme_mod('single_column_second_title',true);
			},
		],
	],
] );

/**
 * single Column second category selection
*/

Kirki::add_field( CONFIGID, array(
	'type'     => 'select',
	'settings' => 'single_column_second_category_selection',
	'label'    => esc_html__( 'Select a category for single column', 'magexpress' ),
	'section'  => SINGLECOLUMNSECTIONSECOND,
	'default'  => '1',
	'priority' => 10,
	'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'category') ))
 );

  /**
 * single Colum second Category Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'single_column_second_posts_order',
	'label'       => esc_html__( 'Single Column Second Posts Order', 'magexpress' ),
	'section'     => SINGLECOLUMNSECTIONSECOND,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );