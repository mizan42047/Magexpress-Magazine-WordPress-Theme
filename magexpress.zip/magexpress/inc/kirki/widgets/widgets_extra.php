<?php 
define('WIDGETSEXTRA','magexpress_widgets_extra_section_id');

/**
 * Widgets Extra Section
 */

Kirki::add_section( WIDGETSEXTRA, array(
    'title'          => esc_html__( 'Widgets Extra', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your Frontpage Sidebar Title', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * Home Sidebar-1 Title
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'home_sidebar_title_1',
	'label'    => esc_html__( 'Home Sidebar-1 Title', 'magexpress' ),
	'section'  => WIDGETSEXTRA,
	'default'  => esc_html__( 'Recent Posts', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'home_sidebar_title_1' => [
			'selector'        => '.home-sidebar-1',
			'render_callback' => function() {
				return get_theme_mod('home_sidebar_title_1',true);
			},
		],
	],
] );

/**
 * Home Sidebar-2 Title
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'home_sidebar_title_2',
	'label'    => esc_html__( 'Home Sidebar-2 Title', 'magexpress' ),
	'section'  => WIDGETSEXTRA,
	'default'  => esc_html__( 'Most Popular', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'home_sidebar_title_2' => [
			'selector'        => '.home-sidebar-2',
			'render_callback' => function() {
				return get_theme_mod('home_sidebar_title_2',true);
			},
		],
	],
] );

/**
 * Home Sidebar-3 Title
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'home_sidebar_title_3',
	'label'    => esc_html__( 'Home Sidebar-3 Title', 'magexpress' ),
	'section'  => WIDGETSEXTRA,
	'default'  => esc_html__( 'Recent Comments', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'home_sidebar_title_3' => [
			'selector'        => '.home-sidebar-3',
			'render_callback' => function() {
				return get_theme_mod('home_sidebar_title_3',true);
			},
		],
	],
] );

/**
 * Home Sidebar-4 Title
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'home_sidebar_title_4',
	'label'    => esc_html__( 'Home Sidebar-4 Title', 'magexpress' ),
	'section'  => WIDGETSEXTRA,
	'default'  => esc_html__( 'Popular Links', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'home_sidebar_title_4' => [
			'selector'        => '.home-sidebar-4',
			'render_callback' => function() {
				return get_theme_mod('home_sidebar_title_4',true);
			},
		],
	],
] );