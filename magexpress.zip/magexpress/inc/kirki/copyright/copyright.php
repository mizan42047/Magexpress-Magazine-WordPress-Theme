<?php
define('COPYSEC','magexpress_copyright_section_id');
/**
 * Theme contact form control.
 */

Kirki::add_section( COPYSEC, array(
    'title'          => esc_html__( 'Copyright', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * Copyright Text
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'footer_copyright',
	'label'    => esc_html__( 'Copyright', 'magexpress' ),
	'section'  => CONTACTSEC,
	'default'  => esc_html__( '&copy;All right reserved by Mijanur Rahman', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'footer_copyright' => [
			'selector'        => '.footer_copyright',
			'render_callback' => function() {
				return get_theme_mod('footer_copyright',true);
			},
		],
	],
] );