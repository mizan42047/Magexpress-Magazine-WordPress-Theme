<?php
define('DOUBLECOLUMNSECTIONSECOND','magexpress_three_column_section_second_section_id');

/**
 * Theme second Double column area post control Section.
 */
Kirki::add_section( DOUBLECOLUMNSECTIONSECOND, array(
    'title'          => esc_html__( 'Double Column second', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your double column area post', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * Double Column second  Title 
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'double_column_second_title',
	'label'    => esc_html__( 'Double second Category Title', 'magexpress' ),
	'section'  => DOUBLECOLUMNSECTIONSECOND,
	'default'  => esc_html__( 'Category Name', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'double_column_second_title' => [
			'selector'        => '.double_column_second_title',
			'render_callback' => function() {
				return get_theme_mod('double_column_second_title',true);
			},
		],
	],
] );

/**
 * Double Column second category selection
*/

Kirki::add_field( CONFIGID, array(
	'type'     => 'select',
	'settings' => 'double_column_second_category_selection',
	'label'    => esc_html__( 'Select a category for double column', 'magexpress' ),
	'section'  => DOUBLECOLUMNSECTIONSECOND,
	'default'  => '1',
	'priority' => 10,
	'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'category') ))
 );

  /**
 * Double Colum second Category Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'double_column_second_posts_order',
	'label'       => esc_html__( 'Double Column second Posts Order', 'magexpress' ),
	'section'     => DOUBLECOLUMNSECTIONSECOND,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );