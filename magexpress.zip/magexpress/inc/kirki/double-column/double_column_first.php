<?php
define('DOUBLECOLUMNSECTIONFIRST','magexpress_three_column_first_section_id');

/**
 * Theme first Double column area post control Section.
 */
Kirki::add_section( DOUBLECOLUMNSECTIONFIRST, array(
    'title'          => esc_html__( 'Double Column First', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your double column area post', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 *  Double Column First Title 
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'double_column_first_title',
	'label'    => esc_html__( 'Double First Category Title', 'magexpress' ),
	'section'  => DOUBLECOLUMNSECTIONFIRST,
	'default'  => esc_html__( 'Category Name', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'double_column_first_title' => [
			'selector'        => '.catg_titile_first_column',
			'render_callback' => function() {
				return get_theme_mod('double_column_first_title',true);
			},
		],
	],
] );

/**
 * Double Column first category selection
*/

Kirki::add_field( CONFIGID, array(
	'type'     => 'select',
	'settings' => 'double_column_first_category_selection',
	'label'    => esc_html__( 'Select a category for double column', 'magexpress' ),
	'section'  => DOUBLECOLUMNSECTIONFIRST,
	'default'  => '1',
	'priority' => 10,
	'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'category') ))
 );

  /**
 * Double Colum first Category Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'double_column_first_posts_order',
	'label'       => esc_html__( 'Double Column First Posts Order', 'magexpress' ),
	'section'     => DOUBLECOLUMNSECTIONFIRST,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );