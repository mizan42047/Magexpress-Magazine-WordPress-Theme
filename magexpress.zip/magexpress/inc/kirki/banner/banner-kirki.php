<?php
define('HEROSECTION','magexpress_hero_section_id');
/**
 * Theme hero area post control.
 */

Kirki::add_section( HEROSECTION, array(
    'title'          => esc_html__( 'Hero Area Posts', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your hero area post', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );
/**
 * Banner Slider Post Selection
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'banner_slider_posts',
	'label'       => esc_html__( 'Banner Slider', 'magexpress' ),
	'section'     => HEROSECTION,
	'default'     => 'latest',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'latest' => esc_html__( 'Latest Posts', 'magexpress' ),
		'featured' => esc_html__( 'Featured Post', 'magexpress' ),
	],
] );

/**
 * Banner Slider Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'banner_slider_posts_order',
	'label'       => esc_html__( 'Banner Slider Posts Order', 'magexpress' ),
	'section'     => HEROSECTION,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
    'active_callback' => [
        [
            'setting'  => 'banner_slider_posts',
            'operator' => '==',
            'value'    => 'featured',
        ]
    ],
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );


/**
 * Bnaner Slider Post Limit
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'slider',
	'settings'    => 'banner_post_limit',
	'label'       => esc_html__( 'Banner Slider Post Limit', 'magexpress' ),
	'section'     => HEROSECTION,
	'default'     => 5,
	'choices'     => [
		'min'  => 1,
		'max'  => 10,
		'step' => 1,
	],
] );

/**
 * DIvider
 */

Kirki::add_field( CONFIGID, [
	'type'        => 'custom',
	'settings'    => 'divider3',
	'section'     => HEROSECTION,
	'default'         => '<hr style="margin:10px 0;background-color:blue;color:#c2c2c2;height:3px;">',
	'priority'    => 10,
] );

/**
 * Banner Right Post Selection
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'banner_right_posts',
	'label'       => esc_html__( 'Banner Right Posts', 'magexpress' ),
	'section'     => HEROSECTION,
	'default'     => 'featured',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'latest' => esc_html__( 'Latest Posts', 'magexpress' ),
		'featured' => esc_html__( 'Featured Post', 'magexpress' ),
	],
] );

/**
 * Banner Right Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'banner_right_posts_order',
	'label'       => esc_html__( 'Banner Right Posts Order', 'magexpress' ),
	'section'     => HEROSECTION,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
    'active_callback' => [
        [
            'setting'  => 'banner_right_posts',
            'operator' => '==',
            'value'    => 'featured',
        ]
    ],
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] ); 