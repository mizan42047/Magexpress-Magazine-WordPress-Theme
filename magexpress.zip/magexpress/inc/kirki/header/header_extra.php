<?php
define('HEADEREXTRASEC','magexpress_header_extra_section_id');

/**
 * Header extra section
 */
Kirki::add_section( HEADEREXTRASEC, array(
    'title'          => esc_html__( 'Header Extra', 'magexpress' ),
    'description'    => esc_html__( 'Setup your header', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * haeader banner image
 */

Kirki::add_field( CONFIGID, [
	'type'        => 'image',
	'settings'    => 'header_banner_img',
	'label'       => esc_html__( 'Header Image(Adds)', 'magexpress' ),
	'description' => esc_html__( 'Description Here.', 'magexpress' ),
	'section'     => HEADEREXTRASEC,
	'default'     => '',
] );

/**
 * Header banner link
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'link',
	'settings' => 'header_banner_img_link',
	'label'    => __( 'Image Link', 'magexpress' ),
	'section'  => HEADEREXTRASEC,
	'default'  => 'https://codermijan.com/',
	'priority' => 10,
] );

