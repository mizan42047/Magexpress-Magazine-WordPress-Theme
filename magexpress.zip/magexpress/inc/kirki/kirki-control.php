<?php
define('CONFIGID', 'magexpress_config_id');
define('THEMEPANELID', 'magexpress_panel_id');


Kirki::add_config( CONFIGID, array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) ); 

Kirki::add_panel( THEMEPANELID, array(
    'priority'    => 10,
    'title'       => esc_html__( 'Magexpress', 'magexpress' ),
    'description' => esc_html__( 'Control your post from here', 'magexpress' ),
) );


require_once('banner/banner-kirki.php');
require_once('three-column/three-column-kirki.php');
require_once('double-column/double_column_first.php');
require_once('single-column/single_column_first.php');
require_once('single-column/single_column_second.php');
require_once('double-column/double_column_second.php');
require_once('widgets/widgets_extra.php');
require_once('contact-form/form_shortcode.php');
require_once('header/header_extra.php');
require_once('copyright/copyright.php');



