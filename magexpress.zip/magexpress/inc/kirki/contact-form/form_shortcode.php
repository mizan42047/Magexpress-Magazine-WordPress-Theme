<?php
define('CONTACTSEC','magexpress_contact_section_id');
/**
 * Theme contact form control.
 */

Kirki::add_section( CONTACTSEC, array(
    'title'          => esc_html__( 'Contact', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your contact form', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * Contact Form Shortcode 
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'contact_form_shortcode',
	'label'    => esc_html__( 'Shortcode', 'magexpress' ),
	'section'  => CONTACTSEC,
	'default'  => esc_html__( '', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'contact_form_shortcode' => [
			'selector'        => '.contact_us',
			'render_callback' => function() {
				return get_theme_mod('contact_form_shortcode',true);
			},
		],
	],
] );

