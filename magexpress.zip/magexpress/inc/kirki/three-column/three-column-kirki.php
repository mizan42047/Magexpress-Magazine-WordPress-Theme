<?php
define('THREECOLUMNSECTION','magexpress_three_column_section_id'); 

/**
 * Theme three column area post control Section.
 */

Kirki::add_section( THREECOLUMNSECTION, array(
    'title'          => esc_html__( 'Three Column Area', 'magexpress' ),
    'description'    => esc_html__( 'Setup Your three column area post', 'magexpress' ),
    'panel'          => THEMEPANELID,
    'priority'       => 160,
) );

/**
 * Three Column Left Title 
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'three_column_left_title',
	'label'    => esc_html__( 'Left Category Title', 'magexpress' ),
	'section'  => THREECOLUMNSECTION,
	'default'  => esc_html__( 'Category Name', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'three_column_left_title' => [
			'selector'        => '.title_text_cat_left',
			'render_callback' => function() {
				return get_theme_mod('three_column_left_title',true);
			},
		],
	],
] );

/**
 * Three Column Left category selection
 */

Kirki::add_field( CONFIGID, array(
	'type'     => 'select',
	'settings' => 'three_column_left_category_selection',
	'label'    => esc_html__( 'Select a category for left column', 'magexpress' ),
	'section'  => THREECOLUMNSECTION,
	'default'  => '1',
	'priority' => 10,
	'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'category') ))
 );

 /**
 * Three Colum Left Category Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'three_column_left_posts_order',
	'label'       => esc_html__( 'Left Posts Order', 'magexpress' ),
	'section'     => THREECOLUMNSECTION,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );

/**
 * DIvider
 */

Kirki::add_field( CONFIGID, [
	'type'        => 'custom',
	'settings'    => 'divider',
	'section'     => THREECOLUMNSECTION,
	'default'         => '<hr style="margin:10px 0;background-color:#c2c2c2;color:#c2c2c2;height:3px;">',
	'priority'    => 10,
] );

/**
 * Three Column Right Title 
 */

Kirki::add_field( CONFIGID, [
	'type'     => 'text',
	'settings' => 'three_column_right_title',
	'label'    => esc_html__( 'Right Category Title', 'magexpress' ),
	'section'  => THREECOLUMNSECTION,
	'default'  => esc_html__( 'Category Name', 'magexpress' ),
	'priority' => 10,
	'partial_refresh'    => [
		'three_column_right_title' => [
			'selector'        => '.title_text_cat_right',
			'render_callback' => function() {
				return get_theme_mod('three_column_right_title',true);
			},
		],
	],
] );

/**
 * Three Column Right category selection
 */

Kirki::add_field( CONFIGID, array(
	'type'     => 'select',
	'settings' => 'three_column_right_category_selection',
	'label'    => esc_html__( 'Select a category for Right Column', 'magexpress' ),
	'section'  => THREECOLUMNSECTION,
	'default'  => '1',
	'priority' => 10,
	'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'category') ))
 );

 /**
 * Three Colum Right Category Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'three_column_right_posts_order',
	'label'       => esc_html__( 'Right Posts Order', 'magexpress' ),
	'section'     => THREECOLUMNSECTION,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );

/**
 * DIvider
 */

Kirki::add_field( CONFIGID, [
	'type'        => 'custom',
	'settings'    => 'divider2',
	'section'     => THREECOLUMNSECTION,
	'default'         => '<hr style="margin:10px 0;background-color:#c2c2c2;color:#c2c2c2;height:3px;">',
	'priority'    => 10,
] );

/**
 * Middle three column category Slider
 */

Kirki::add_field( CONFIGID, array(
	'type'     => 'select',
	'settings' => 'three_column_slider_category_selection',
	'label'    => esc_html__( 'Select a category for Slider', 'magexpress' ),
    'description' => esc_html__('This category for Three Column Area Slider','magexpress'),
	'section'  => THREECOLUMNSECTION,
	'default'  => '1',
	'priority' => 10,
	'choices'     => Kirki_Helper::get_terms( array('taxonomy' => 'category') ))
 );

  /**
 * Three Colum Slider Category Post Order
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'select',
	'settings'    => 'three_column_slider_posts_order',
	'label'       => esc_html__( 'Slider Posts Order', 'magexpress' ),
	'section'     => THREECOLUMNSECTION,
	'default'     => 'date',
	'placeholder' => esc_html__( 'Select an option...', 'magexpress' ),
	'priority'    => 10,
	'choices'     => [
		'date' => esc_html__( 'Date', 'magexpress' ),
		'title' => esc_html__( 'Title', 'magexpress' ),
        'author'=> esc_html__( 'Author', 'magexpress' ),
        'rand'=> esc_html__( 'Random', 'magexpress' ),
        'comment_count'=> esc_html__( 'Comments Number', 'magexpress' ),
	],
] );

/**
 * Three Column Slider Post Limit
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'slider',
	'settings'    => 'category_slider_post_limit',
	'label'       => esc_html__( 'Three Column Slider Post Limit', 'magexpress' ),
	'section'     => THREECOLUMNSECTION,
	'default'     => 5,
	'choices'     => [
		'min'  => 1,
		'max'  => 10,
		'step' => 1,
	],
] );

/**
 * Three Column Slider Post excerpt
 */
Kirki::add_field( CONFIGID, [
	'type'        => 'slider',
	'settings'    => 'category_slider_post_excerpt',
	'label'       => esc_html__( 'Three Column Slider Post Limit', 'magexpress' ),
	'section'     => THREECOLUMNSECTION,
	'default'     => 200,
	'choices'     => [
		'min'  => 50,
		'max'  => 250,
		'step' => 10,
	],
] );

