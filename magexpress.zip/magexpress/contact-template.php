<?php
/**
 * Template Name:Contact
 */
get_header();
?>

<section id="ContactContent">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="contact_area">
            <h1><?php _e(get_the_title(),'magexpress'); ?></h1>
            <?php 
            if(get_the_content()){
                the_content();
            } 
            ?>
            
            <div class="contact_bottom">
              <div class="contact_us wow fadeInRightBig">
                <?php 
                if(get_theme_mod('contact_form_shortcode')){
                   echo do_shortcode(sanitize_text_field(get_theme_mod('contact_form_shortcode')));
                }
                
                ?>
              </div>
            </div>
          </div>
        </div>
      </div>
</section>

<?php get_footer(); ?>

