<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Mag_Express
 */

get_header();
?>

<section id="mainContent">
  <div class="content_bottom">
    <div class="col-lg-8 col-md-8">
      <div class="content_bottom_left">
        <div class="single_category wow fadeInDown">
          <div class="archive_style_1">
            <div style="margin-top:15px;">
              <ol class="breadcrumb">
                <li><a href="<?php echo esc_url(site_url()); ?>"><?php esc_html_e(get_the_title(get_option('page_on_front')), 'magexpress'); ?></a>
                </li>
                <li class='active'><?php single_term_title(); ?></a>
                </li>
              </ol>
            </div>
            <h2> <span class="bold_line"><span></span></span> <span class="solid_line"></span> <span class="title_text"><?php _e(get_the_archive_title(), 'magexpress'); ?></span> </h2>

            <?php 
            
            if(have_posts()){
              while(have_posts()){
                the_post();
                get_template_part('template-parts/content');
              }
            }else{
              get_template_part('template-parts/content','none');
            }
            
            ?>
            
          </div>
        </div>
      </div>
      <div class="pagination_area">
        <nav>
          <ul class="pagination">
            <?php
				
			the_posts_pagination();	

            ?>
          </ul>
        </nav>
      </div>
    </div>
    <?php get_sidebar(); ?>
  </div>
</section>

<?php
get_footer();
