<?php
/**
 * Mag Express functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Mag_Express
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'magexpress_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function magexpress_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Mag Express, use a find and replace
		 * to change 'magexpress' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'magexpress', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'main-menu' => esc_html__( 'Primary', 'magexpress' ),
				'topbar-menu' => esc_html('Top Bar','magexpress'),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		$html_args = array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		);

		add_theme_support(
			'html5',$html_args);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'magexpress_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'magexpress_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function magexpress_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'magexpress_content_width', 1200 );
}
add_action( 'after_setup_theme', 'magexpress_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function magexpress_widgets_init() {
		register_sidebar(
			array(
				'name'          => esc_html__( 'Sidebar 1', 'magexpress' ),
				'id'            => 'home-sidebar-1',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Sidebar 2', 'magexpress' ),
				'id'            => 'home-sidebar-2',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Sidebar 3', 'magexpress' ),
				'id'            => 'home-sidebar-3',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Sidebar 4', 'magexpress' ),
				'id'            => 'home-sidebar-4',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Single Page Sidebar', 'magexpress' ),
				'id'            => 'sigle-page-sidebar',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);

		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer 1', 'magexpress' ),
				'id'            => 'footer-1',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer 2', 'magexpress' ),
				'id'            => 'footer-2',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Footer 3', 'magexpress' ),
				'id'            => 'footer-3',
				'description'   => esc_html__( 'Add widgets here.', 'magexpress' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
}
add_action( 'widgets_init', 'magexpress_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function magexpress_scripts() {

	wp_enqueue_style( 'bootstrap', get_theme_file_uri('/assets/css/bootstrap.min.css'), array(), _S_VERSION );
	wp_enqueue_style( 'fontAwesome', get_theme_file_uri('/assets/css/font-awesome.min.css'), array(), _S_VERSION );
	wp_enqueue_style( 'animate', get_theme_file_uri('/assets/css/animate.css'), array(), _S_VERSION );
	wp_enqueue_style( 'slick', get_theme_file_uri('/assets/css/slick.css'), array(), _S_VERSION );
	wp_enqueue_style( 'theme-style', get_theme_file_uri('/assets/css/theme.css'), array(), _S_VERSION );
	wp_enqueue_style( 'template-styleshet', get_theme_file_uri('/assets/css/style.css'), array(), _S_VERSION );
	wp_enqueue_style( 'magexpress-style', get_stylesheet_uri(), array('template-styleshet'), _S_VERSION );
	wp_style_add_data( 'magexpress-style', 'rtl', 'replace' );

	wp_enqueue_script( 'magexpress-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );
	wp_enqueue_script( 'bootstrap', get_theme_file_uri('/assets/js/bootstrap.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'wow', get_theme_file_uri('/assets/js/wow.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'slick', get_theme_file_uri('/assets/js/slick.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'custom', get_theme_file_uri('/assets/js/custom.js'), array('jquery'), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'magexpress_scripts' );


/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load Kirki Customizer Framework
 */
if(class_exists('Kirki')){
	require_once('inc/kirki/kirki-control.php');
}

/**
 * Custom Widgets
 */

 require_once('inc/widgets/flicker_img.php');


 add_filter( 'get_the_archive_title', function ($title) {    
	if ( is_category() ) {    
			$title = single_cat_title( '', false );    
		} elseif ( is_tag() ) {    
			$title = single_tag_title( '', false );    
		} elseif ( is_author() ) {    
			$title = '<span class="vcard">' . get_the_author() . '</span>' ;    
		} elseif ( is_tax() ) { //for custom post types
			$title = sprintf( __( '%1$s' ), single_term_title( '', false ) );
		} elseif (is_post_type_archive()) {
			$title = post_type_archive_title( '', false );
		}
	return $title;    
});
 

/**
 * TGM includes
 */
require_once('inc/tgm.php');
 


