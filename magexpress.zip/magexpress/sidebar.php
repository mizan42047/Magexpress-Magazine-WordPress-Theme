<div class="col-lg-4 col-md-4">
    <div class="content_bottom_right">
        <div class="single_bottom_rightbar">
        <?php if(get_theme_mod('home_sidebar_title_1')): ?>    
        <h2 class="home-sidebar-1">
                <?php _e(sanitize_text_field(get_theme_mod('home_sidebar_title_1',true)),'magexpress');?>
        </h2>
        <?php endif; ?>
            <?php 
            
            if(is_active_sidebar('home-sidebar-1')){
                dynamic_sidebar('home-sidebar-1');
            }
            
            ?>
        </div>
        <div class="single_bottom_rightbar">
            <ul role="tablist" class="nav nav-tabs custom-tabs">
                <li class="active" role="presentation"><a class="home-sidebar-2" data-toggle="tab" role="tab" aria-controls="home" href="#mostPopular">
                <?php 
                if(get_theme_mod('home_sidebar_title_2')){
                    _e(sanitize_text_field(get_theme_mod('home_sidebar_title_2',true)),'magexpress');
                }
                ?>
                </a></li>
                <li role="presentation"><a class="home-sidebar-3" data-toggle="tab" role="tab" aria-controls="messages" href="#recentComent">
                <?php 
                if(get_theme_mod('home_sidebar_title_3')){
                    _e(sanitize_text_field(get_theme_mod('home_sidebar_title_3',true)),'magexpress');
                }
                ?>
                </a></li>
            </ul>
            <div class="tab-content">
                <div id="mostPopular" class="tab-pane fade in active" role="tabpanel">
                    <?php 
                    if(is_active_sidebar('home-sidebar-2')){
                        dynamic_sidebar('home-sidebar-2');
                    }
                    
                    ?>
                </div>
                <div id="recentComent" class="tab-pane fade" role="tabpanel">
                    <?php 
                    if(is_active_sidebar('home-sidebar-3')){
                        dynamic_sidebar('home-sidebar-3');
                    }
                    
                    ?>
                </div>
            </div>
        </div>
        <div class="single_bottom_rightbar wow fadeInDown">
        <?php if(get_theme_mod('home_sidebar_title_4')): ?>    
            <h2 class="home-sidebar-4">
                    <?php _e(sanitize_text_field(get_theme_mod('home_sidebar_title_4',true)),'magexpress');?>
            </h2>
        <?php endif; ?>
            <?php 
            if(is_active_sidebar('home-sidebar-4')){
                dynamic_sidebar('home-sidebar-4');
            }
            
            ?>
        </div>
    </div>
</div>