<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Mag_Express
 */

get_header();
?>

<section id="mainContent">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="error_page_content">
          <h1><?php _e('404','magexpress'); ?></h1>
          <h2><?php _e('Sorry :(','magexpress'); ?></h2>
          <h3><?php _e('This page does not exist.','magexpress'); ?></h3>
          <p class="wow fadeInLeftBig"><?php _e('Please, continue to our','magexpress'); ?> <a href="<?php echo site_url(); ?>"><?php _e('Home Page','magexpress'); ?></a></p>
        </div>
      </div>
    </div>
  </section>

<?php
get_footer();
