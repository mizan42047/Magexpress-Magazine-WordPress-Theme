<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mag_Express
 */

?>

<footer id="footer">
  <div class="footer_top">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="single_footer_top wow fadeInLeft">
        
            <?php 
            
            if(is_active_sidebar('footer-1')){
              dynamic_sidebar('footer-1');
            }
            
            ?>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="single_footer_top wow fadeInDown">
            <?php 
            if(is_active_sidebar('footer-2')){
              dynamic_sidebar('footer-2');
            }
            
            ?>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4">
          <div class="single_footer_top wow fadeInRight">
            <?php 
            if(is_active_sidebar('footer-3')){
              dynamic_sidebar('footer-3');
            }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer_bottom">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="footer_bottom_left">
            <p class="footer_copyright"><?php if(get_theme_mod('footer_copyright')) echo sanitize_text_field(esc_html_e(get_theme_mod('footer_copyright','true'),'magexprss')) ?></p>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="footer_bottom_right">
            <p>Designed BY Wpfreeware And Developed by Mijanur Rahman</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>