<?php
if(get_theme_mod('three_column_left_category_selection')){
    $catgory_id = get_theme_mod('three_column_left_category_selection',true);
    $catgory_link = get_category_link(sanitize_text_field($catgory_id));
}else{
    $catgory_id = 1;
    $catgory_link = get_category_link($catgory_id);
}

if(!get_theme_mod('three_column_left_posts_order')){
    $post_order = 'date';
}else{
    $post_order = get_theme_mod('three_column_left_posts_order');
}

$three_left_query = new WP_Query([
    'posts_per_page' => '2',
    'limit'          => '2',
    'post_type'      => 'post',
    'cat'            => sanitize_text_field($catgory_id),
    'orderby'        => sanitize_text_field($post_order),
]);
?>
<div class="content_middle_leftbar">
    <div class="single_category wow fadeInDown">
        <h2> <span class="bold_line"><span></span></span> <span class="solid_line"></span> <a href="<?php echo esc_url($catgory_link); ?>" class="title_text title_text_cat_left">
        <?php if(get_theme_mod('three_column_left_title')) _e(get_theme_mod('three_column_left_title','Category Name'), 'magexpress'); ?>
    </a> </h2>
        <ul class="catg1_nav">
            <?php if ($three_left_query->have_posts()) : while ($three_left_query->have_posts()) : $three_left_query->the_post(); ?>
                    <li <?php post_class(); ?>>
                        <div class="catgimg_container">
                            <a href="<?php esc_url(the_permalink()); ?>" class="catg1_img"><img alt="<?php esc_attr(the_title()); ?>" src="<?php esc_url(the_post_thumbnail_url()); ?>"></a>
                        </div>
                        <h3 class="post_titile"><a href="<?php esc_url(the_permalink()); ?>"><?php _(the_title()); ?></a></h3>
                    </li>
            <?php endwhile;
            endif;wp_reset_query(); ?>
        </ul>
    </div>
</div>