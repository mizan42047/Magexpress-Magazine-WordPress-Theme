<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Mag_Express
 */

?>

<section id="mainContent">
	<div class="content_bottom">
		<div class="col-lg-8 col-md-8">
			<div class="content_bottom_left">
				<div class="single_page_area">
					<ol class="breadcrumb">
						<li><a href="<?php echo site_url(); ?>"><?php echo __(get_the_title(get_option('page_on_front')), 'magexpress'); ?></a></li>
						<li><?php esc_html__(the_category(" "), 'magexpress') ?></li>
						<li class="active"> <?php __(the_title(), 'magexpress'); ?> </li>
					</ol>
					<h2 class="post_titile"> <?php __(the_title(), 'magexpress'); ?> </h2>
					<div class="single_page_content">
						<div class="post_commentbox"> <i class="fa fa-edit"> </i> <?php esc_html__(the_author_posts_link(), 'magexpress'); ?> <span><i class="fa fa-calendar"></i><?php esc_html_e(get_the_time('h:ia')); ?></span><i class="fa fa-tags"> </i> <?php esc_html__(the_category(' ')); ?></div>
						<?php if (has_post_thumbnail()) : ?>
							<img class="img-center" src="<?php esc_url(the_post_thumbnail_url()); ?>" alt="<?php esc_attr(the_title()); ?>">
						<?php endif; ?>

						<?php __(the_content(), 'magexpress'); ?>

						<?php
						$prev = get_previous_post();
						$next = get_next_post();
						?>

					</div>
				</div>
			</div>
			<?php if($prev && $next): ?>
                <div class="post_pagination">
				<div class="prev"> <a class="angle_left" href="<?php echo esc_url($prev->guid); ?>"><i class="fa fa-angle-double-left"></i></a>
					<div class="pagincontent"> <span><?php _e('Previous Post', 'magexpress'); ?></span> <a href="<?php echo esc_url($prev->guid); ?>"><?php esc_html_e($prev->post_title, 'magexpress'); ?></a> </div>
				</div>

				<div class="next">
					<div class="pagincontent"> <span><?php _e('Next Post', 'magexpress'); ?></span> <a href="<?php echo esc_url($next->guid); ?>"><?php esc_html_e($next->post_title, 'magexpress'); ?></a> </div>
					<a class="angle_right" href="<?php echo esc_url($next->guid); ?>"><i class="fa fa-angle-double-right"></i></a>
				</div>
			    </div>
            <?php endif; ?>    

			<div class="similar_post">
				<h2><?php _e('Similar Post You May Like','magexpress'); ?> <i class="fa fa-thumbs-o-up"> </i></h2>
				<ul class="small_catg similar_nav wow fadeInDown animated">
					<?php 
					
					$post_id = get_the_ID();
					$post_category = get_the_category($post_id)[0];
					$post_category_id = $post_category->cat_ID;

					$related_posts = new WP_Query([
						'posts_per_page'   => '3',
						'cat'			   => $post_category_id,
						'post__not_in'     => [$post_id],
						'limit'			   =>'3',
						'orderby'		   => 'date'
					]);

					if($related_posts->have_posts()):while($related_posts->have_posts()):
					$related_posts->the_post();
					?>
					<li>
						<div class="media wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;"> <a class="media-left related-img" href="<?php esc_url(the_permalink()); ?>"><img src="<?php esc_url(the_post_thumbnail_url()); ?>" alt="<?php esc_attr__( the_title(), 'magexpress' ) ?>"></a>
							<div class="media-body">
								<h4 class="media-heading"><a href="<?php esc_url(the_permalink()); ?>"><?php esc_html__(the_title(),'magexpress'); ?></a></h4>
								<?php
								$excerpt = get_the_excerpt();

								$excerpt = substr($excerpt, 0, 200);
								$result = substr($excerpt, 0, strrpos($excerpt, ' '));
								echo $result;
								?>
							</div>
						</div>
					</li>
					<?php endwhile;endif; ?>
				</ul>
			</div>
		</div>
		<?php get_sidebar(); ?>
	</div>
</section>