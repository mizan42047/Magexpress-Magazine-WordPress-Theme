<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Mag_Express
 */

?>



<div class="business_category_left wow fadeInDown">
	<ul class="fashion_catgnav">
		<li <?php post_class(); ?>>
			<?php if(has_post_thumbnail()): ?>
				<div class="catgimg2_container"> <a href="<?php esc_url(the_permalink()); ?>">
				<img alt="<?php esc_attr(the_title()); ?>" src="<?php esc_url(the_post_thumbnail_url()); ?>"></a> </div>
			<?php endif; ?>	
			<h2 class="catg_titile"><a href="<?php esc_url(the_permalink()); ?>"><?php esc_html__(the_title(), 'magexpress'); ?></a></h2>
			<div class="comments_box"> <span class="meta_date"><?php esc_html_e(get_the_date(), 'magexpress'); ?></span> <span class="meta_comment"><a href="<?php esc_url(the_permalink()); ?>">
						<?php

						if (get_comment_count()['approved'] > 0) {
							echo get_comment_count()['approved'];
						} else {
							_e('No Comment', 'magexpress');
						}

						?>
					</a></span> <span class="meta_more"><a href="<?php esc_url(the_permalink()); ?>"><?php _e('Read More...', 'magexpress'); ?></a></span> </div>
			<?php
			$excerpt_limit = (get_theme_mod('category_slider_post_excerpt')) ? sanitize_text_field(get_theme_mod('category_slider_post_excerpt', true)) : 200;
			$excerpt = get_the_excerpt();
			$excerpt = substr($excerpt, 0, $excerpt_limit);
			$result = substr($excerpt, 0, strrpos($excerpt, ' '));
			echo $result;
			?>
		</li>
	</ul>
</div>