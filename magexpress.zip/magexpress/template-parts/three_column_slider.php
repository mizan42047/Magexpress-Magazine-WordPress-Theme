<?php
$cat_id = (get_theme_mod('three_column_slider_category_selection'))?sanitize_text_field(get_theme_mod('three_column_slider_category_selection',true)):1;
$post_order = (get_theme_mod('three_column_slider_posts_order'))?get_theme_mod('three_column_slider_posts_order') : 'date';
$post_limit = (get_theme_mod('category_slider_post_limit'))?sanitize_text_field(get_theme_mod('category_slider_post_limit')) : '5';

$middle_category_slider = new WP_Query([
    'posts_per_page' => $post_limit,
    'limit'          => $post_limit,
    'post_type'      => 'post',
    'cat'            => $cat_id,
    'orderby'        => $post_order,
]);


?>
<div class="content_middle_middle">
    <div class="slick_slider2">
        <?php if($middle_category_slider->have_posts()):while($middle_category_slider->have_posts()):$middle_category_slider->the_post(); ?>
        <div class="single_featured_slide">
            <a href="<?php esc_url(the_permalink()); ?>"><img src="<?php esc_url(the_post_thumbnail_url()); ?>" alt="<?php esc_attr(the_title()); ?>">
            </a>
            <h2><a href="<?php esc_url(the_permalink()); ?>"><?php _(the_title()); ?></a></h2>
            <?php
            $excerpt_limit = (get_theme_mod('category_slider_post_excerpt'))?sanitize_text_field(get_theme_mod('category_slider_post_excerpt',true)):200;
            $excerpt = get_the_excerpt();
            $excerpt = substr($excerpt, 0, $excerpt_limit);
            $result = substr($excerpt, 0, strrpos($excerpt, ' '));
            echo $result;
            ?>
        </div>
        <?php endwhile;endif;wp_reset_query(); ?>
    </div>
</div>