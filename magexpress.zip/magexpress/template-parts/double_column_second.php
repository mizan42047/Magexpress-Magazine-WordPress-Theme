<?php
$category_id = (get_theme_mod('double_column_second_category_selection'))?get_theme_mod('double_column_second_category_selection',true):1;
$post_order = (get_theme_mod('double_column_second_posts_order'))?get_theme_mod('double_column_second_posts_order',true) : 'date';
$double_column_second = get_posts([
    'post_type'      => 'post',
    'posts_per_page' => '4',
    'limit'          => '4',
    'orderby'        => $post_order,
    'cat'            => $category_id,
]);

?>
<div class="single_category wow fadeInDown">
    <h2> <span class="bold_line"><span></span></span> <span class="solid_line"></span>
        <a class="title_text double_column_second_title" href="<?php echo esc_url(get_category_link($category_id)); ?>">
        <?php 
        if(get_theme_mod('double_column_second_title')){
            _e(get_theme_mod('double_column_second_title',true),'magexpress');
        }
        ?>
        </a>
    </h2>
    <div class="business_category_left wow fadeInDown">
        <ul class="fashion_catgnav">
            <li <?php post_class(); ?>>
                <div class="catgimg2_container"> <a href="<?php esc_url(the_permalink($double_column_second[0]->guid)); ?>"><img alt="<?php esc_attr_e(get_the_title($double_column_second[0]->ID)); ?>" src="<?php echo esc_url(get_the_post_thumbnail_url($double_column_second[0]->ID)); ?>"></a></div>
                <h2 class="catg_titile"><a href="<?php echo esc_url(get_the_permalink($double_column_second[0]->ID)); ?>"><?php esc_html_e(get_the_title($double_column_second[0]->ID), 'magexpress'); ?></a></h2>
                <div class="comments_box"> <span class="meta_date">
                        <?php esc_html_e(get_the_date('', $double_column_second[0]->ID), 'magexpress'); ?>
                    </span> <span class="meta_comment"><a href="<?php esc_url(get_the_permalink($double_column_second[0]->ID)); ?>">
                            <?php
                            $comments_count = get_comment_count($double_column_second[0]->ID);
                            if ($comments_count['approved'] > 0) {
                                esc_html_e($comments_count['approved'], 'magexpress');
                            } else {
                                _e('No Comments', 'magexpress');
                            }
                            ?>

                        </a></span> <span class="meta_more"><a href="<?php esc_url(the_permalink()); ?>"><?php _e('Read More..', 'magexpress'); ?></a></span> </div>
                <p>
                    <?php
                    $excerpt = get_the_excerpt($double_column_second[0]->ID);

                    $excerpt = substr($excerpt, 0, 100);
                    $result = substr($excerpt, 0, strrpos($excerpt, ' '));
                    echo $result;
                    ?>

                </p>
            </li>
        </ul>
    </div>
    <div class="business_category_right wow fadeInDown">
        <ul class="small_catg">
            <?php

            for ($i = 1; $i < count($double_column_second); $i++) {
            ?>
                <li <?php post_class(); ?>>
                    <div class="media wow fadeInDown">
                        <a class="media-left" href="<?php echo esc_url(get_the_permalink($double_column_second[$i]->ID)); ?>"><img src="<?php echo esc_url(get_the_post_thumbnail_url($double_column_second[$i]->ID)); ?>" alt="<?php esc_attr_e(get_the_title($double_column_second[$i]->ID), 'magexpress'); ?>">
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading"><a href="<?php echo esc_url(get_the_permalink($double_column_second[$i]->ID)) ?>"><?php esc_html(_e(get_the_title($double_column_second[$i]->ID), 'magexpress')); ?></a></h4>
                            <div class="comments_box"> <span class="meta_date"><?php sanitize_text_field(_e(get_the_date('', $double_column_second[$i]->ID), 'magexpress')) ?></span> <span class="meta_comment"><a href="<?php echo esc_url(get_the_permalink($double_column_second[$i]->ID)); ?>">
                                        <?php
                                        $comments_count = get_comment_count($double_column_second[$i]->ID);
                                        if ($comments_count['approved'] > 0) {
                                            esc_html_e($comments_count['approved'], 'magexpress');
                                        } else {
                                            _e('No Comments', 'magexpress');
                                        }
                                        ?>
                                    </a>
                                </span>
                            </div>
                        </div>
                    </div>
                </li>
            <?php };
            wp_reset_postdata(); ?>
        </ul>
    </div>
</div>