<?php

/**
 * check what type of post
 * if post = latest then meta key and meta value will be empty 
 * else meta_value and key will be feture and 1 
 * and check is user select any post order if select then the orderby will be the user orderby
 * 
 */

if(get_theme_mod('banner_right_posts')){
    $query = get_theme_mod('banner_right_posts');
    if(sanitize_text_field($query) === 'latest'){
        $meta_key = '';
        $meta_value = '';
        $orderby = 'date';
    }else{
        $meta_key = 'featured_news';
        $meta_value = '1';
        if(get_theme_mod('banner_right_posts_order')){
            $orderby = sanitize_text_field(get_theme_mod('banner_right_posts_order',true));
        }
    }
}
/**
 * This is the banner right query there is set default limit=4 because of site design
 */
$banner_right_query = new WP_Query([
    'posts_per_page' => '4',
    'orderby' => $orderby,
    'limit' => '4',
    'meta_key' => $meta_key,
    'meta_value' => $meta_value,
]);


?>
<div class="col-lg-6 col-md-6 col-sm6">
    <div class="content_top_right">
        <ul class="featured_nav wow fadeInDown">
            <?php if($banner_right_query->have_posts()):while($banner_right_query->have_posts()):$banner_right_query->the_post(); ?>
            <li <?php post_class(); ?>><img src="<?php esc_url(the_post_thumbnail_url()); ?>" alt="<?php esc_attr(the_title()); ?>">
                <div class="title_caption"><a href="<?php esc_url(the_permalink()); ?>"><?php _(the_title()); ?></a></div>
            </li>
            <?php endwhile;endif;wp_reset_query(); ?>
        </ul>
    </div>
</div>