<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Mag_Express
 */

?>

<section id="mainContent">
    <div class="content_bottom">
      <div class="col-lg-8 col-md-8">
        <div class="content_bottom_left">
          <div class="single_page_area">
            <ol class="breadcrumb">
              <li><a href="<?php echo site_url(); ?>"><?php echo __(get_the_title(get_option('page_on_front')),'magexpress'); ?></a></li>
              <li class="active"><?php __(the_title(),'magexpress'); ?></li>
            </ol>
            <h2 class="post_titile"> <?php _(the_title()); ?> </h2>
            <div class="single_page_content">
               <?php if(has_post_thumbnail()): ?>
				<img src="<?php esc_url(the_post_thumbnail_url()); ?>" alt="<?php esc_attr_e(get_the_title(),'magexpress') ?>">
				<?php endif; ?>
			   <?php __(the_content(),'magexpress'); ?>
            </div>
          </div>
        </div>
      </div>
      <?php get_sidebar(); ?>
  </section>
