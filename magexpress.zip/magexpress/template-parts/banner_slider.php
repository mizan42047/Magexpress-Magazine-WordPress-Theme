<?php
/**
 * Check Kirki field and set the post limit
 */
$limit = (get_theme_mod('banner_post_limit'))?get_theme_mod('banner_post_limit',true):5;


/**
 * Check What type of post
 * if post == featured then meta key and meta value will added with query and check is orderby exist if exixst then order will be like client order
 * if post == latest then meta key and meta value will not added so we do not need any orderby.so I set it to date.
 */

if(get_theme_mod('banner_slider_posts')){
    $query = get_theme_mod('banner_slider_posts');
    if($query==='featured'){
        $orderby = (get_theme_mod('banner_right_posts_order')) ? sanitize_text_field(get_theme_mod('banner_right_posts_order',true)) : 'date';
        $banner_slider_query = new WP_Query([
            'post_type' => 'post',
            'posts_per_page' => $limit,
            'limit' => $limit,
            'ignore_sticky_posts' => true,
            'orderby' => $orderby,
            'meta_key'=> 'featured_news',
            'meta_value' => '1',
        ]);
       
    }else{
        $banner_slider_query = new WP_Query([
            'post_type' => 'post',
            'posts_per_page' => $limit,
            'limit' => $limit,
            'ignore_sticky_posts' => true,
            'orderby' => 'date',
        ]);
    }
}

?>
<div class="col-lg-6 col-md-6 col-sm6">
    <div class="latest_slider">
        <div class="slick_slider">
            <?php 
            if($banner_slider_query->have_posts()){
                while($banner_slider_query->have_posts()){
                    $banner_slider_query->the_post();
            ?>
            <div <?php post_class(['single_iteam']); ?>>
            <img src="<?php esc_url(the_post_thumbnail_url());?>" alt="<?php the_title() ?>">
                <h2><a class="slider_tittle" href="<?php esc_url(the_permalink()); ?>"><?php _(the_title()); ?></a>
                </h2>
            </div>
            <?php }};wp_reset_query(); ?>
        </div>
    </div>
</div>