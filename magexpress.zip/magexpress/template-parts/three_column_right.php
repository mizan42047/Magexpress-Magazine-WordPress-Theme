<?php
if(get_theme_mod('three_column_right_category_selection')){
    $category_id = sanitize_text_field(get_theme_mod('three_column_right_category_selection',true));
}else{
    $category_id = 1;
}

if(!get_theme_mod('three_column_right_posts_order')){
    $post_order = 'date';
}else{
    $post_order = sanitize_text_field(get_theme_mod('three_column_right_posts_order',true));
}

$hollywood_query = new WP_Query([
    'posts_per_page' => '2',
    'limit'          => '2',
    'post_type'      => 'post',
    'cat'            => $category_id,
    'orderby'        => $post_order,
]);
?>
<div class="content_middle_rightbar">
    <div class="single_category wow fadeInDown">
        <h2> <span class="bold_line"><span></span></span> <span class="solid_line"></span> <a href="<?php echo get_category_link($category_id); ?>" class="title_text title_text_cat_right">
        <?php if(get_theme_mod('three_column_right_title')) _e(get_theme_mod('three_column_right_title','Category Name'), 'magexpress'); ?>
        </a> </h2>
        <ul class="catg1_nav">
        <?php if ($hollywood_query->have_posts()) : while ($hollywood_query->have_posts()) : $hollywood_query->the_post(); ?>
                    <li <?php post_class(); ?>>
                        <div class="catgimg_container">
                            <a href="<?php esc_url(the_permalink()); ?>" class="catg1_img"><img alt="<?php esc_attr(the_title()); ?>" src="<?php esc_url(the_post_thumbnail_url()); ?>"></a>
                        </div>
                        <h3 class="post_titile"><a href="<?php esc_url(the_permalink()); ?>"><?php _(the_title()); ?></a></h3>
                    </li>
            <?php endwhile;
            endif;wp_reset_query();?>
        </ul>
    </div>
</div>